# AimLock V2 Premium

Android UI demo with a login screen and red/black premium-style menu.

Login account: `Ob55`

The password is required at login and is masked; it is not displayed on the menu.

The menu controls are UI-only demonstrations and do not modify or interfere with any game client, anti-cheat, registry, or game files.

## GitHub Actions
Open **Actions → Build AimLock V2 Premium**. The workflow uses Java 17 and Gradle 8.7 and uploads `AimLock-V2-Premium-APK` when the build succeeds.


Build workflow v2: no Gradle cache, Java 17, Android SDK 35, Gradle 8.9.
